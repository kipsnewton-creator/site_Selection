"""site_suitability_Project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from site_suitability_APP import views

urlpatterns = [
    path('admin/', admin.site.urls),
    re_path(r'inputs', views.my_form, name='inputs'),

    path('',views.map.as_view(), name='map'),    
    re_path('drawn_roi',views.drawn_roi.as_view(),name='drawn_roi'),
    re_path('load_roi_Data',views.load_roi_Data.as_view(),name='load_roi_Data'),
    re_path('buffer_region',views.buffer_region.as_view(),name='buffer_region'),
    re_path('LULC',views.LULC.as_view(),name='LULC'),   
    re_path('ED',views.ED.as_view(),name='ED'),
    re_path('muranga_roi',views.muranga_roi.as_view(),name='muranga_roi'), 
    re_path('studyarea',views.studyarea.as_view(),name="studyarea"), 
    re_path('reclass_slope',views.reclass_slope.as_view(),name="reclass_slope"),  
    re_path('overlay',views.overlay.as_view(),name="overlay")   
 

]
