from django.shortcuts import render

# Create your views here.
from fileinput import filename
from django.shortcuts import redirect, render
from django.http import HttpResponse
import warnings
import numpy as np


from requests import request 
warnings.filterwarnings('ignore')
# Create your views here.
from telnetlib import AO
from django.shortcuts import render

from matplotlib.pyplot import cla, draw, figure
from sqlalchemy import false

import collections
collections.Callable = collections.abc.Callable

# Create your views here.

import folium
from django.views.generic import TemplateView 
import geemap
import geemap.foliumap as geemap
import ipyleaflet 
import ee 
import geopandas as gdp
import pandas as pd
from geemap import Map

#connection to DATABASE
import psycopg2 as ps
import psycopg2
from folium import plugins
from folium.plugins import Draw
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
#sending emails
from django.core.mail import send_mail
from sklearn import metrics
import numpy as np
####
import os
from os import path as op
import pandas as pd
import geopandas as gpd
import pyogrio

import matplotlib # base python plotting library
import matplotlib.pyplot as plt # submodule of matplotlib

#####################################
########Map layout set up!!!!!!#####
###################################
class map(TemplateView):
        template_name = 'index.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[-0.7292563329434308,37.16490937388146],
            zoom_start=13,
            plugin_Draw = True, 
            Draw_export = True
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )
                          }
                        
                # basemaps['Google Maps'].add_to(Map)
                # basemaps['Esri Satellite'].add_to(Map)
                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"map": figure}
#####End of map template #####
##############################
#Drawn Region 
class drawn_roi(TemplateView):
        template_name = 'drawn_roi.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[-0.7292563329434308,37.16490937388146],
            zoom_start=8,
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
  
                global export_data
                export_data=gdp.read_file(r"C:\Users\user\Downloads\data.geojson")
                
                global feature_collection
                feature_collection = geemap.gdf_to_ee(export_data)#FROM GDF TO ee feature collection
                style = {'color': '131313', 'fillColor':' #05f23e'}
                Map.center_object(feature_collection,8);

                Map.addLayer(feature_collection,{},"Selected ROI")
    
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"drawn_roi": figure}
###End of drawn ROI
class muranga_roi(TemplateView):
        template_name = 'muranga_ROI.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[-0.7292563329434308,37.16490937388146],
            zoom_start=8,
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
  
                ee.Initialize()
                global feature_collection
                feature_collection = ee.FeatureCollection('projects/ee-kimutailawrence19/assets/Muranga');

                style = {'color': '131313', 'fillColor':' #05f23e'}
                
                Map.center_object(feature_collection,8);
                Map.addLayer(feature_collection,{}, "Selected ROI")
    
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"muranga_roi": figure}
####################
###Load ROI Data########

class load_roi_Data(TemplateView):
    template_name = 'load_roi_Data.html'
    def get_context_data(request):
        figure = folium.Figure()
        Map = geemap.Map(
        location=[-0.7292563329434308,37.16490937388146],
        zoom_start=13,
            # plugin_Draw = True, 
        #     Draw_export = True
        )
        Map.add_to(figure)
        
        style = {'color': '131313', 'fillColor':' FD0505'}
                

        basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )
                          
                          }
                        
        # global export_data
                
        # global feature_collection
        # feature_collection = geemap.gdf_to_ee(export_data)#FROM GDF TO ee feature collection
        # style = {'color': '131313', 'fillColor':' #05f23e'}
        Map.center_object(feature_collection,12);    
#
        srtm=ee.Image("USGS/SRTMGL1_003")
        elev = srtm.select('elevation');
# Get slope
        slope = ee.Terrain.slope(elev);
# Map.addLayer(slope,{},"slope")

# Clip Srtm DEM by geometry
        ROI_slope= slope.clip(feature_collection);
        slope_palette1 = ['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000']
        Map.addLayer(ROI_slope,{'palette':slope_palette1},"ROI_slope")
            
                #Reading Data:
        global ken_roads
        ken_roads = ee.FeatureCollection("projects/ee-mosongjnvscode/assets/KEN_roads")
                # Reading Health Centers
        global health_centers
        health_centers = ee.FeatureCollection("projects/ee-mosongjnvscode/assets/kenya_health")
                #Reading Rivers Data
        global rivers
        rivers = ee.FeatureCollection("projects/ee-mosongjnvscode/assets/kenya_rivers")
        
        Map.addLayer(feature_collection,{},"Selected ROI")
        
        buildings = ee.FeatureCollection('GOOGLE/Research/open-buildings/v1/polygons');
        global ROI_building
        ROI_building=buildings\
            .filter('confidence >= 0.70')\
                .filterBounds(feature_collection)\

        buildings_vispar=['00FF00']

        Map.addLayer(ROI_building,{'color': 'ff0000'},"ROI Population")
#Health Care:Roi clipped
        global health_centers_clip
        health_centers_clip= health_centers.filterBounds(feature_collection)
        global HC_style
        HC_style = {'color': '131313', 'fillColor':'#ced610'}
        Map.addLayer(health_centers_clip.style(**HC_style),{}, "HC ROI")

#Roads: Roi clipped
        global ken_roads_clip
        ken_roads_clip= ken_roads.filterBounds(feature_collection)
        roads_style = {'color': '131313', 'fillColor':'#000000'}
        Map.addLayer(ken_roads_clip,{'color': '000000'},"Roads ROI")

#Rivers: Roi clipped
        global rivers_clip
        rivers_clip= rivers.filterBounds(feature_collection)
        HC_style = {'color': '0000FF', 'fillColor':'#0000FF'}
        Map.addLayer(rivers_clip,{'color': '0000FF'}, "Rivers ROI")
        
        
      
        
        legend_dict = {
        'Roads':'000000',
        'River':'0000FF',
        'Buildings':'FF0000',
        'slope':'00FF00',
        'Health Center':'FFFF00'

    
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')

        Map.add_child(folium.LayerControl())
                
        figure.render()
                
        return{"load_roi_Data": figure}
            
        

#####################################
########Buffer for various features###
###################################
#Image preprocessing:2017
class buffer_region(TemplateView):
    template_name = 'buffer.html'
    def get_context_data(request):
        figure = folium.Figure()
        Map = geemap.Map(
        location=[-0.7292563329434308,37.16490937388146],
        zoom_start=13,
            # plugin_Draw = True, 
        #     Draw_export = True
        )
        Map.add_to(figure)
        Map.center_object(feature_collection,8);

        
        style = {'color': '131313', 'fillColor':' FD0505'}
                

        basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )}

#Connection to Database:
        global connection
        connection=ps.connect(dbname="site_selection88",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
        cursor=connection.cursor()
        sql="""SELECT * FROM "site_suitability_APP_setting_parameters" WHERE Id=(SELECT max(Id) FROM "site_suitability_APP_setting_parameters");"""
        cursor.execute(sql)
        data=cursor.fetchall()
        
#Setting Roads  dataafrom DB
        for Roads in data:
            ("Roads=",Roads[1])
        Roads_parameter =Roads[1]

#Rivers Readings from Django user Inputs:Row 2
        for Rivers in data:
            ("Rivers=",Rivers[2])
        Rivers_parameter =Rivers[2]
##Health_centers Readings from Django user Inputs:Row 4 

        for Health_centers  in data:
            ("Health_Center=",Health_centers [3])
        health_center_parameter =Health_centers [3]

        for population_data in data:
            ("Population =",population_data[4])
        population_parameter=population_data[4]
        
        print("Roads_parameter:",Roads_parameter )
        print("Rivers_parameter :",Rivers_parameter )
        print("health_center:",health_center_parameter )
        print("population:",population_parameter)


              #Create Buffer Regions:
#Building and Population Buffer:
        Map.addLayer(feature_collection,{},"Selected ROI")

        global Bufferred_building
        Bufferred_building= ROI_building.map(lambda f: f.buffer(population_parameter))
        Map.addLayer(Bufferred_building,{'color': '64d615'},"Population Buffer(M)",false)
#Roads Buffer:
        global roads_buffer
        roads_buffer= ken_roads_clip.map(lambda f: f.buffer(Roads_parameter))
        Map.addLayer(roads_buffer,{'color': 'ce0ad6'},"roads_buffer(M)")
#River Buffer:
        river_buffer= rivers_clip.map(lambda f: f.buffer(Rivers_parameter))
        Map.addLayer(river_buffer,{'color': '64d615'},"river_buffer(M)")
#Population Buffer:
        HC_bufferred= health_centers_clip.map(lambda f: f.buffer(health_center_parameter))
        HC_style_buffered = {'color': '131313', 'fillColor':'#4dcdd6'}
        Map.addLayer(HC_bufferred,{'color': '64d615'}, "health_centers_Buffer(M)")
        
                          
#Orginal Datasets:
        Map.addLayer(feature_collection,{},"Selected ROI")
        Map.addLayer(rivers_clip,{'color': '123ef4'}, "non_buffer_Rivers")
        Map.addLayer(ken_roads_clip,{'color': '040100'},"non_buffer_Roads")
        Map.addLayer(health_centers_clip.style(**HC_style),{}, "non_buffer_HC")
        Map.addLayer(ROI_building,{'color': 'ff0000'},"non_buffer_Population",false)
        
        legend_dict = {
   'Roads Buffer(M)':'ce0ad6',
    'Non Buffer Roads':'040100',
    'River Buffer(M)':'64d615',
    'Non buffer Rivers': '123ef4',
    'Non Buffer Population': 'ff0000',
    'Population Buffer(M)':'64d615',
    'Non Buffer HC':'131313',
    'Health Centers Buffer':'00FF00'
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')
        
         
        Map.add_child(folium.LayerControl())
                
        figure.render()   
        return{"buffer_region": figure}
            


 
#Myform for data:
from django.shortcuts import render
from .models import setting_parameters
from .forms import MyForm1
class input(TemplateView): 
    template_name = 'index.html'
def my_form(request):
  if request.method == "POST":
    form = MyForm1(request.POST)
    if form.is_valid():
      form.save()
  else:
      form = MyForm1()
  return render(request, 'parameters.html', {'form': form})


     
####################
#####Euclidean Distance:#####
class ED(TemplateView):
    template_name = 'Eudclidean.html'
    def get_context_data(request):
        figure = folium.Figure()
        Map = geemap.Map(
        location=[-0.7292563329434308,37.16490937388146],
        zoom_start=13,
        plugin_Draw = True, 
        Draw_export = True
        )
        Map.add_to(figure)
#Fetch Data from Database:
#Connection to Database:
        global connection
        connection=ps.connect(dbname="site_selection88",#Database_name
                 user="postgres",#Database user name
                 password="Mosong6783",##Database_passcode.
                 host="localhost",#Database host
                 port="5432"##Db operational port
                )
        cursor=connection.cursor()
        sql="""SELECT * FROM "site_suitability_APP_setting_parameters" WHERE Id=(SELECT max(Id) FROM "site_suitability_APP_setting_parameters");"""
        cursor.execute(sql)
        data=cursor.fetchall()
        
#Setting Roads  dataafrom DB
        for ED_Roads in data:
                ("ED_Roads=",ED_Roads[5])
                ED_Roads_parameter =ED_Roads[5]
        for ED_Rivers in data:
                ("Rivers=",ED_Rivers[6])
                ED_Rivers_parameter =ED_Rivers[6]
 
        for ED_Health_centers  in data:
                ("ED_Health_centers=",ED_Health_centers [7])
                ED_Health_centers_parameter =ED_Health_centers [7]

        for ED_population_data in data:
                ("ED_population_data =",ED_population_data[8])
                ED_population_parameter=ED_population_data[8]



        print("ED_Roads_parameter:",ED_Roads_parameter)
        print("ED_Rivers_parameter :",ED_Rivers_parameter)
        print("ED_health_center:",ED_Health_centers_parameter)
        print("ED_population:",ED_population_parameter)
        
        Map.addLayer(feature_collection,{}, "Selected ROI")

        ### Eucliden Distance for Rivers:
        def func_dwt(feat):
                return feat.set("class",1)

        rivers_clip_new= rivers_clip.map(func_dwt)
        

# Make an image out of the population attribute and display it.
        global rivers_clip_ed
        rivers_clip_ed =rivers_clip_new.reduceToImage(**{
    'properties': ['class'],
    'reducer': ee.Reducer.first()})

        inputs=1000
        kernel = ee.Kernel.euclidean(ED_Rivers_parameter ,"meters")
        river_distance = rivers_clip_ed.distance(kernel,False).clip(feature_collection)
        Map.centerObject(feature_collection,12)

        palette= ['green', 'yellow','red']
        Map.addLayer(river_distance,{'min':0, 'max':1000,'palette': palette},'Rivers_ED')

### Eucliden Distance for Roads:
        def func_dwt(feat):
                return feat.set("class",1)

        ken_roads_clip_new= ken_roads_clip.map(func_dwt)

# Make an image out of the population attribute and display it.
        global ken_roads_clip_ed
        ken_roads_clip_ed =ken_roads_clip_new.reduceToImage(**{
    'properties': ['class'],
    'reducer': ee.Reducer.first()})

        inputs=1000
        kernel = ee.Kernel.euclidean(ED_Roads_parameter ,"meters")
        Roads_distance = ken_roads_clip_ed.distance(kernel,False).clip(feature_collection)

        palette= ['green', 'yellow','red']
        Map.addLayer(Roads_distance,{'min':0, 'max':1000,'palette': palette},'Roads_ED')
#Search Radius for point data:
        test_input=52000
        health_centers_ED = health_centers_clip.distance(**{'searchRadius':ED_Health_centers_parameter })

# Display the image and FeatureCollection on the map.
        Map.centerObject(feature_collection,12)

        Map.addLayer(health_centers_ED.clip(feature_collection), {'max': 50000,'palette': palette}, 'health_centers_ED')
        Map.addLayer(health_centers_clip.style(**HC_style),{}, "health_centers_clip")
        
        legend_dict = {
   'High':'FF0000',
    'Medium':'FFFF00',
    'Lowwer':'00FF00'
                }
        Map.add_legend(legend_dict=legend_dict,position='topleft')
        
        Map.add_child(folium.LayerControl())

        figure.render()    
        return{"ED": figure}


         
####################
###LULC#######
class LULC(TemplateView):
    template_name = 'LULC.html'
    def get_context_data(request):
        figure = folium.Figure()
        Map = geemap.Map(
        location=[-0.7292563329434308,37.16490937388146],
        zoom_start=13,
            plugin_Draw = True, 
            Draw_export = True
        )
        Map.add_to(figure)
        
        style = {'color': '131313', 'fillColor':' FD0505'}
                

        basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )
                          
                          }
                        
        # basemaps['Google Maps'].add_to(Map)
        # basemaps['Esri Satellite'].add_to(Map)
        global export_data
        export_data=gdp.read_file(r"C:\Users\user\Downloads\data.geojson")
                
        global feature_collection
        feature_collection = geemap.gdf_to_ee(export_data)#FROM GDF TO ee feature collection
        style = {'color': '131313', 'fillColor':' #05f23e'}
        Map.center_object(feature_collection,12);                

#Dyanmic world Image Classifcation:
        global start_date
        start_date="2020-01-01"#Set start_date(yy/mon/day)
        global end_date
        end_date="2020-03-31"#Set End_date(yy/mon/day)

         
        region=feature_collection
     
        image = geemap.dynamic_world_s2(region, start_date, end_date)
        vis_params3 = {'bands': ['B4', 'B3', 'B2'], 'min': 0, 'max': 3000}
        global landcover
                # Create Dynamic World land cover composite
        global landcover
        landcover = geemap.dynamic_world(region, start_date, end_date, return_type='hillshade')

                # Add legend to the map
        # Map.add_legend(title="Land Cover", builtin_legend='Dynamic_World')
        # Map.addLayer(landcover.clip(region),{},'LULC') 
#Muranga:
        Muranga = ee.FeatureCollection('projects/ee-kimutailawrence19/assets/Muranga');
        Muranga_training= ee.FeatureCollection('projects/ee-mosongjnvscode/assets/muranga_training');

        Map.addLayer(Muranga_training,{},"Muranga_training")
        Map.addLayer(Muranga,{},"Muranga")
        
        start_date="2020-01-01"#Set start_date(yy/mon/day)
        end_date="2020-03-31"#Set End_date(yy/mon/day)
        season = ee.Filter.date(start_date,end_date);#Filter image based on the time frame(start_date and end_date)

#-------------SENTINEL 1(SAR) DATA------------------#
        sentinel_1= ee.ImageCollection('COPERNICUS/S1_GRD');
        sCollection=sentinel_1\
                .filterBounds(Muranga) \
                        .filter(season) \
                                .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV')) \
                                        .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH')) \
                                                .filter(ee.Filter.eq('instrumentMode', 'IW'))
        desc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'));
        asc=sCollection.filter(ee.Filter.eq('orbitProperties_pass', 'ASCENDING'));
#Create a composite between Sentinel 1 and 2
        composite = ee.Image.cat([
                asc.select('VH').mean(),
                asc.select('VV').mean(),
                desc.select('VH').mean()
                ]).focal_median();

        
        #-------------SENTINEL_2A DATA------------------#
        sentinel_2A = ee.ImageCollection('COPERNICUS/S2')\
                .filterBounds(Muranga)\
                        .filterDate("2020-01-01","2020-03-31")\
                                .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE",12))\
                                        .median()\
                                                .select('B1','B2', 'B3', 'B4', 'B5', 'B6', 'B7','B8', 'B10', 'B11')\
                                                        .clip(Muranga)

        sentinel_2Avispar={"min":0, "max":2500,"bands": ['B4','B3','B2']}#Visualization parameters used.
        
#Training data
        training_data=ee.FeatureCollection('projects/ee-mosongjnvscode/assets/muranga_training001');
        # Map.addLayer(training_data,{},"Kisrian_Training_Data")
        buffered_data = training_data.map(lambda f: f.buffer(5))
        
        label='landcover'
        bands=["B4","B3","B2"]

        trainImage=sentinel_2A.sampleRegions(**{
                'collection':training_data,
                'properties':[label],
                'scale':30
                })
        trainingData=trainImage.randomColumn()

        trainSet=trainingData.filter(ee.Filter.lessThan('random',0.75))
        testdata=trainingData.filter(ee.Filter.greaterThanOrEquals('random',0.75))


#visualization parameters applied on the Random forest classifier

        init_params = {"numberOfTrees":10, # the number of individual decision tree models
              "variablesPerSplit":None,  # the number of features to use per split
              "minLeafPopulation":1, # smallest sample size possible per leaf
              "bagFraction":0.5, # fraction of data to include for each individual tree model
              "maxNodes":None, # max number of leafs/nodes per tree
               "seed":0}  # random seed for "random" choices like sampling. Setting this allows others to reproduce your exact results even with stocastic parameters
        global classifier

        classifier = ee.Classifier.smileRandomForest(**init_params).train(trainImage, label, bands)
# Classify the image.

#Application of the random forest classifier for the purpose of image classification.
        global classified
        classified=sentinel_2A.classify(classifier)
        palette = [
  '2a9a12', #forest(0)
  '000aa3',#water(1)
  '080802', #builtup(2)
  'ff4311', #grassland(3)
  'f2f130' #agriculture(4)
    ];
        Map.addLayer(classified,{'min': 0, 'max': 4, 'palette': palette},'classification')
        legend_dict = {
    'BareLand': 'd6ba61',#1
    'Buildings': '09080c',#
    'Vegetation': '33698b',#
    'Agricultral': 'ff2407',
    'Water Bodies': '00ffff',#
                }

#Reclassify the LULC and slope:
                # Reclass forest
        Reclass_Forest= classified.updateMask(classified.eq(0))
        Reclass_Forest_viz=['39ea13']
#Reclassify water
        Reclass_water= classified.updateMask(classified.eq(1))
        Reclass_water_viz=['0a40ea']
#Reclassify Buildings
        Reclass_buildings= classified.updateMask(classified.eq(2))
        Reclass_buildings_viz=['000000']
        Map.addLayer(Reclass_buildings,{'palette':Reclass_buildings_viz},"Reclass_buildings")
#Reclassify Grassland
        Reclass_Grassland= classified.updateMask(classified.eq(3))
        Reclass_Grassland_viz=['c95e0b']
#Reclassify Agriculture
        Reclass_Agriculture= classified.updateMask(classified.eq(4))
        Reclass_Agriculture_viz=['b4c950']
        
        # Conversion to FeatureCollection Collection 

# Convert the zones of the thresholded nightlights to vectors.
        vectors = Reclass_Forest.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 1000,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        display = ee.Image(0).updateMask(0).paint(vectors, '000000', 3)
        Map.addLayer(display, {'palette': '000000'}, 'Forest_Boundary ')
        
        
        
        ########################NEW
        # Conversion to FeatureCollection Collection 

# Convert the zones of the thresholded nightlights to vectors.
        vectors = Reclass_Forest.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 1000,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        Forest_Boundary = ee.Image(0).updateMask(0).paint(vectors, '1cd62e', 3)
        Map.addLayer(Forest_Boundary, {'palette': '1cd62e'}, 'Forest_Boundary ')

# forest_classified = display.map(lambda f: f.buffer(25))
# Map.addLayer(forest_classified, {'palette': '000000'}, 'forest_classified ')

# Conversion to FeatureCollection Collection 

# Convert the zones of the thresholded nightlights to vectors.
        vectors001 = Reclass_water.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 50,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        Water_Boundary = ee.Image(0).updateMask(0).paint(vectors001, '0922ff', 3)
        Map.addLayer(Water_Boundary, {'palette': '0922ff'}, 'Water_Boundary')

# Convert the zones of the thresholded nightlights to vectors.
        vectors002 = Reclass_buildings.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 50,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        Buildings_Boundary = ee.Image(0).updateMask(0).paint(vectors002, 'ff0000', 3)
        Map.addLayer(Buildings_Boundary, {'palette': 'ff0000'}, 'Buildings_Boundary')

# Convert the zones of the thresholded nightlights to vectors.
        Reclass_Grassland_vectors = Reclass_Grassland.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 50,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        GrassLand_Boundary = ee.Image(0).updateMask(0).paint(Reclass_Grassland_vectors, 'afffa2', 3)
        Map.addLayer(GrassLand_Boundary, {'palette': 'afffa2'}, 'GrassLand_Boundary')

# Convert the zones of the thresholded nightlights to vectors.
        Reclass_Agriculture_vectors = Reclass_Agriculture.addBands(classified).reduceToVectors(**{
  'geometry': Muranga,
  'crs': classified.projection(),
  'scale': 50,
  'geometryType': 'polygon',
  'eightConnected': False,
  'labelProperty': 'zone',
  'reducer': ee.Reducer.mean()
})
# Make a display image for the vectors, add it to the map.
        Agricultural_Boundary = ee.Image(0).updateMask(0).paint(Reclass_Agriculture_vectors, 'fffe64', 3)
        Map.addLayer(Agricultural_Boundary, {'palette': 'fffe64'}, 'Agricultural_Boundary')
#Legend:
        
           # Add legend to the map
        legend_dict = {
    'Agricultural Boundary':'fffe64',
    'GrassLand_Boundary': 'afffa2',
    'Buildings_Boundary':'ff0000',
    'Water_Boundary':'0922ff',
    'Forest_Boundary':'1cd62e',
   }
        Map.add_legend(legend_dict=legend_dict,position='topleft')

        Map.add_child(folium.LayerControl())
        figure.render()    
        return{"LULC": figure}

        
class studyarea(TemplateView):
        
         template_name='studyarea.html'
         
# Slope reclassification.
###End of drawn ROI
class reclass_slope(TemplateView):
        template_name = 'slope_reclass.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[-0.7292563329434308,37.16490937388146],
            zoom_start=8,
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
  
                ee.Initialize()
                global feature_collection
                feature_collection = ee.FeatureCollection('projects/ee-kimutailawrence19/assets/Muranga');

                style = {'color': '131313', 'fillColor':' #05f23e'}
                
                Map.center_object(feature_collection,8);
                Map.addLayer(feature_collection,{}, "Selected ROI")
                Muranga = feature_collection
                
                srtm=ee.Image("USGS/SRTMGL1_003")
                elev = srtm.select('elevation');
# Get slope
                slope = ee.Terrain.slope(elev);
# Map.addLayer(slope,{},"slope")

# Clip Srtm DEM by geometry
                global muranga_slope
                muranga_slope= slope.clip(Muranga);
                slope_palette1 = ['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000']
                Map.addLayer(muranga_slope,{'palette':slope_palette1}," Orginal slope")
                slope_palette = ['ff0000','0000FF']
###Quarying and Reclassification.
#SAMPLE EXAMPLE OF RECLASSIFICATION BASED ON RANGE:
                global first_class
                first_class=ee.Image(1) \
                        .where(muranga_slope.gt(5).And(muranga_slope.lte(10)), 2) \
                        .where(muranga_slope.gt(10).And(muranga_slope.lte(15)), 3) \
                        .where(muranga_slope.gt(15).And(muranga_slope.lte(20)), 4) \
                        .where(muranga_slope.gt(20).And(muranga_slope.lte(25)), 5) \
                        .where(muranga_slope.gt(25).And(muranga_slope.lte(45)), 6) \
                        .where(muranga_slope.gt(45).And(muranga_slope.lte(100)), 7)

                vis_params = {          'min': 0,
                        'max': 41,
                        'palette':['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000'],
                    }
                colors = vis_params['palette']
                vmin = vis_params['min']
                vmax = vis_params['max']
# Map_test.addLayer(final_class.clip(Muranga),vis_params,"final_class")

                slope_palette = ['0C7600','4CE500','B2FF18','FFFF00','FFAE00','ff6d66','FF0000']
#Area Calculation (sq.km.)
#Display Reclassified slope image
                Map.addLayer(first_class.clip(Muranga), {'min':1, 'max':7, 'palette':slope_palette}, 'Reclassified Slope')
                
                
                # Add legend to the map
                legend_dict = {
    '0-5':'0C7600',
    '5-10': '4CE500',
    '10-15':'B2FF18',
    '15-20':'FFFF00',
    '20-25':'FFAE00',
    '25-45':'ff6d66',
    '>45':'FF0000'
                }
                Map.add_legend(legend_dict=legend_dict,position='topleft')

    
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"reclass_slope": figure}
        
        #####################################
class overlay(TemplateView):
        template_name = 'overlay.html'
        def get_context_data(request):
                figure = folium.Figure()
                Map = geemap.Map(
            location=[-0.7292563329434308,37.16490937388146],
            zoom_start=8,
        )
                Map.add_to(figure)
        
                style = {'color': '131313', 'fillColor':' FD0505'}
                
                basemaps = {
                 'Google Maps': folium.TileLayer(
        tiles = 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        attr = 'Google',
        name = 'Google Maps',
        overlay = False,
        control = True
    ),
            'Esri Satellite': folium.TileLayer(
        tiles = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attr = 'Esri',
        name = 'Esri Satellite',
        overlay = True,
        control = True
    )
                          
                          }
                Map.addLayer(feature_collection,{},"selected_ROI")

                #Slope VS ED EXISTING HOSPITALS
                inputs2=10
                kernel = ee.Kernel.euclidean(inputs2 ,"meters")
                Roads_distance1 = ken_roads_clip_ed.distance(kernel,False).clip(feature_collection)
                Map.centerObject(feature_collection,12)
                inputs4=1000
                
                kernel = ee.Kernel.euclidean(inputs4,"meters")
                river_distance1 = rivers_clip_ed.distance(kernel,False).clip(feature_collection)
                Map.centerObject(feature_collection,12)

                test_input=52000
                health_centers_ED1 = health_centers_clip.distance(**{'searchRadius':test_input })

                palette= ['green', 'yellow','red']
                diff = first_class.multiply(health_centers_ED1)
                palette1=[
  '#1cd62e',#Forest :0  
  '#ff0000',#Buildings:1
  '#afffa2',#Vegetation:2
  '#fffe64',#Agricultral:3#
  '#0922ff', #Water Bodies4#
]
                Map.addLayer(diff.clip(feature_collection),{'min':0, 'max':10000,'palette': palette},'Overlaid')
                Map.centerObject(feature_collection,12)
                mosaic = ee.ImageCollection([health_centers_ED1, Roads_distance1]).mosaic()
                # Map.addLayer(mosaic,{'min':0, 'max':10000,'palette': palette}, 'mosaic');

#Addition of rivers and Roads;
                road_rivers88 = river_distance1.add(Roads_distance1)

                # Roads  VS Rivers
                inputs2=10
                kernel = ee.Kernel.euclidean(inputs2 ,"meters")
                Roads_distance1 = ken_roads_clip_ed.distance(kernel,False).clip(feature_collection)

                inputs4=1000
                kernel = ee.Kernel.euclidean(inputs4,"meters")
                river_distance1 = rivers_clip_ed.distance(kernel,False).clip(feature_collection)
                Map.centerObject(feature_collection,12)
                
                test_input=52000
                health_centers_ED1 = health_centers_clip.distance(**{'searchRadius':test_input })


                road_rivers = river_distance1.multiply(Roads_distance1)
                Map.addLayer(road_rivers.clip(feature_collection),{'min':0, 'max':1000,'palette': palette},'road+rivers')
                # Map.addLayer(feature_collection,{},"test")
                Map.centerObject(feature_collection,12)
                output=diff.blend(road_rivers)
                
                legend_dict = {
   'Under 30%':'FF0000',
    'Over 50':'FFFF00',
    'Over 80%':'00FF00'
                }
                Map.add_legend(legend_dict=legend_dict,position='topleft')

                
                Map.add_child(folium.LayerControl())
                
                figure.render()
                
                return{"overlay": figure}
#####End of map template #####
##############################