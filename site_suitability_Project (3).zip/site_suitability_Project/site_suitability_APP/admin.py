from django.contrib import admin
from .models import setting_parameters
# Register your models here.
class setting_parameters001(admin.ModelAdmin):  
    list_display =('Road','Rivers','Health_Center','Buildings','ED_Road','ED_Rivers','ED_Health_Center','ED_Buildings')
admin.site.register(setting_parameters,setting_parameters001)
