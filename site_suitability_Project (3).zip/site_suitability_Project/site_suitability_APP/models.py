from django.db import models



from django.contrib.gis.db import models
from django.db.models import Manager as GeoManager

# Create your models here.

class setting_parameters(models.Model):
    Road=models.IntegerField()
    Rivers=models.IntegerField()
    Health_Center=models.IntegerField()   
    Buildings=models.IntegerField()
    ED_Road=models.IntegerField()
    ED_Rivers=models.IntegerField()
    ED_Health_Center=models.IntegerField()   
    ED_Buildings=models.IntegerField()
    

    