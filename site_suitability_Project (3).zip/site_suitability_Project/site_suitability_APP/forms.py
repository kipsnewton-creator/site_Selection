from django import forms

from .models import setting_parameters


class MyForm1(forms.ModelForm):
    class Meta:
        model = setting_parameters
        fields = ["Road", "Rivers","Health_Center","Buildings","ED_Road", "ED_Rivers","ED_Health_Center","ED_Buildings"]
        labels = {'Road': "Roads Buffer(M)", "Rivers": "Rivers Buffer(M)","Health_Center":"Existing-HC(M)","Buildings":"Population Buffer(M)",'ED_Road': "ED Road(M)", "ED_Rivers": "ED Rivers(M)",
                  "Health_Center":"Buffer Existing HC(M)","ED_Buildings":"ED Built-up(M)"}
        
# class MyForm2(forms.ModelForm):
#     class Meta:
#         model = ed_parameters
#         fields = []
#         labels = {}
        